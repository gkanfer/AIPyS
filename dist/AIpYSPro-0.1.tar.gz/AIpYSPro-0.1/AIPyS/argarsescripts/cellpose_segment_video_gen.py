#
# python cellpose_segment_video_gen --dir <images_directory> --pretrained_model cyto --diameter <your_diameter_value> --save_tif

